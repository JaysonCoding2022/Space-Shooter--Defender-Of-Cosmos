import pygame
import random
import sys

# Define some colors
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

# Set up the game screen
SCREEN_WIDTH = 700
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Space Shooter: The Defender of Cosmos")  # Title of the Game
icon = pygame.image.load('img/icon.png')
pygame.display.set_icon(icon)

background = pygame.image.load('img/bg.jpg')

# Define the base class for all game objects
class GameObject(pygame.sprite.Sprite):
    def __init__(self, image, x, y, speed):
        super().__init__()
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.speed = speed

    def update(self):
        self.rect.y += self.speed

class Bullet(GameObject):
    def __init__(self, image, x, y, speed, damage):
        super().__init__(image, x, y, speed)
        self.damage = damage

# Define the player's ship class
class Player(GameObject):
    def __init__(self, image, x, y, speed):
        super().__init__(image, x, y, speed)
        self._health = 100
        self._score = 0
        self._level = 1
        self._score_to_next_level = 100  # Initial score required to reach next level
        self._bullet_level = 1

    @property
    def health(self):
        return self._health

    @health.setter
    def health(self, value):
        self._health = value

    @property
    def score(self):
        return self._score

    @score.setter
    def score(self, value):
        self._score = value

    @property
    def level(self):
        return self._level

    @level.setter
    def level(self, value):
        self._level = value

    @property
    def score_to_next_level(self):
        return self._score_to_next_level

    @score_to_next_level.setter
    def score_to_next_level(self, value):
        self._score_to_next_level = value

    @property
    def bullet_level(self):
        return self._bullet_level

    @bullet_level.setter
    def bullet_level(self, value):
        self._bullet_level = value

    def update(self):
        #Player Movements
        keys = pygame.key.get_pressed()
        # Player Movements > arrow keys
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT] and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_UP] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_DOWN] and self.rect.bottom < SCREEN_HEIGHT:
            self.rect.y += self.speed
        # Player Movements > WASD
        if keys[pygame.K_a] and self.rect.left > 0:
            self.rect.x -= self.speed
        if keys[pygame.K_d] and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.speed
        if keys[pygame.K_w] and self.rect.top > 0:
            self.rect.y -= self.speed
        if keys[pygame.K_s] and self.rect.bottom < SCREEN_HEIGHT:
            self.rect.y += self.speed


        # Check if player's score is enough to level up
        if self.score >= self.score_to_next_level:
            self.level += 1
            self.score_to_next_level += 200 * self.level  # Increase score threshold for next level
            # Additional level-up actions can be added here

            # Bullet level up
            if self.bullet_level < len(bullet_imgs):  # Ensure bullet level does not exceed available bullet images
                self.bullet_level += 1


# Define the enemy ship class
class Enemy(GameObject):
    def __init__(self, image, x, y, speed, health):
        super().__init__(image, x, y, speed)
        self.max_health = health
        self.health = health
        self.health_bar_length = self.rect.width
        self.health_bar_color = GREEN

    def draw_health_bar(self):
        pygame.draw.rect(screen, self.health_bar_color, (self.rect.x, self.rect.y - 10, self.health_bar_length, 5))
        pygame.draw.rect(screen, WHITE, (self.rect.x, self.rect.y - 10, self.rect.width, 5), 1)

    def update(self):
        super().update()  # Call the parent class update method for movement or other behaviors
        self.health_bar_length = self.rect.width * (self.health / self.max_health)


# Define the boss class
class BigEnemy(Enemy):
    def __init__(self, image, x, y, speed, health):
        super().__init__(image, x, y, speed, health)
        self.max_health = health * 2 # Big enemy has 2 times more health than regular enemies
        self.health = health * 2
        self.health_bar_length = self.rect.width
        self.health_bar_color = GREEN
        self.shoot_delay = 150  # Delay between shots
        self.shoot_timer = 0

    def shoot(self):
        # Check if enough time has passed since the last shot
        if self.shoot_timer <= 0:
            laser1_img = pygame.image.load("img/enemy_bullet1.png").convert_alpha()  # Load  laser image
            laser1 = Laser(self.rect.centerx, self.rect.bottom, laser1_img)  # Example parameters, adjust as needed
            lasers.add(laser1)
            all_sprites.add(laser1)
            self.shoot_timer = self.shoot_delay  # Reset the shoot timer
        else:
            self.shoot_timer -= 1
# Define the boss class
class Boss(Enemy):
    def __init__(self, image, x, y, speed, health):
        super().__init__(image, x, y, speed, health)
        self.max_health = health * 7  # Boss has 7 times more health than regular enemies
        self.health = health * 7
        self.health_bar_length = self.rect.width
        self.health_bar_color = GREEN
        self.shoot_delay = 250  # Delay between shots
        self.shoot_timer = 0

    def shoot(self):
        # Check if enough time has passed since the last shot
        if self.shoot_timer <= 0:
            laser_img = pygame.image.load("img/enemy_bullet.png").convert_alpha()  # Load boss laser image
            laser = Laser(self.rect.centerx, self.rect.bottom, laser_img)  # Example parameters, adjust as needed
            lasers.add(laser)
            all_sprites.add(laser)
            self.shoot_timer = self.shoot_delay  # Reset the shoot timer
        else:
            self.shoot_timer -= 1

class Laser(GameObject):
    def __init__(self, x, y, image, source=None):
        super().__init__(image, x, y, 3)  # Laser moves downwards with positive speed
        self.source = source  # Store the source of the laser (enemy)
        
class Explosion(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.images = explosion_imgs
        self.index = 0
        self.image = self.images[self.index]
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.frame_rate = 3  # Change explosion frame every 3 ticks
        self.frame_count = 0

    def update(self):
        self.frame_count += 1
        if self.frame_count % self.frame_rate == 0:
            self.index += 1
            if self.index >= len(self.images):
                self.kill()  # Remove explosion sprite when animation ends
            else:
                self.image = self.images[self.index]
                self.rect = self.image.get_rect(center=self.rect.center)

# Initialize Pygame
pygame.init()
pygame.mixer.init()

# Load background music
pygame.mixer.music.load('music/bg_music.mp3')

# Set the volume level (0.0 to 1.0)
pygame.mixer.music.set_volume(0.1)  # Set the volume to 30%

# Play the music indefinitely
pygame.mixer.music.play(-1)

# Load shooting sound
shooting_sound = pygame.mixer.Sound('music/laser_pew.mp3')
shooting_sound.set_volume(0.3)

# Load destroyed sound
destroyed_sound = pygame.mixer.Sound('music/explosion.mp3')
destroyed_sound.set_volume(0.1)

collision_sound = pygame.mixer.Sound('music/collision_sound.mp3')
collision_sound.set_volume(0.3)

# Enemy Damage Sounds
hit_sound = pygame.mixer.Sound('music/hit_sounds_enemy.mp3')
hit_sound.set_volume(0.5)



# Lost Sound
lost_sound = pygame.mixer.Sound('music/dead_sounds_funny.mp3')
lost_sound.set_volume(0.8)

# Load images
player_img = [
    pygame.image.load("img/arcade.png").convert_alpha(),
    pygame.image.load("img/arcade1.png").convert_alpha(),
    pygame.image.load("img/arcade2.png").convert_alpha(),
    pygame.image.load("img/arcade3.png").convert_alpha()
    ]
        

bullet_imgs = [
    pygame.image.load("img/0.png").convert_alpha(),
    pygame.image.load("img/1.png").convert_alpha(),
    pygame.image.load("img/2.png").convert_alpha(),
    pygame.image.load("img/01.png").convert_alpha(),  
    pygame.image.load("img/12.png").convert_alpha(),
    pygame.image.load("img/3.png").convert_alpha(),
    pygame.image.load("img/4.png").convert_alpha(),
    pygame.image.load("img/5.png").convert_alpha(),
    pygame.image.load("img/5.png").convert_alpha(),
    pygame.image.load("img/6.png").convert_alpha(),
]

explosion_imgs = [
    pygame.image.load("exp/exp1.png").convert_alpha(),
    pygame.image.load("exp/exp2.png").convert_alpha(),
    pygame.image.load("exp/exp3.png").convert_alpha(),
    pygame.image.load("exp/exp4.png").convert_alpha(),
    pygame.image.load("exp/exp5.png").convert_alpha(),
]
numbering = 0
# Create player object
selected_spaceship_index = numbering
player = Player(player_img[selected_spaceship_index], SCREEN_WIDTH // 2, SCREEN_HEIGHT - 50, 8)

# Create sprite groups
all_sprites = pygame.sprite.Group()
enemies = pygame.sprite.Group()
bullets = pygame.sprite.Group()
lasers = pygame.sprite.Group()
all_sprites.add(player)



def draw_spaceship():
    # Draw the current spaceship image based on the selected index
    screen.blit(player_img[selected_spaceship_index], (SCREEN_WIDTH // 4, SCREEN_HEIGHT // 2 + 220))
    
def change_spaceship():
    # Update the global variable to cycle through the available spaceship images
    global selected_spaceship_index
    global numbering
    selected_spaceship_index = (selected_spaceship_index + 1) % len(player_img)


# Define a function for the main game loop
paused = False

# Define a function to toggle the pause state
def toggle_pause():
    global paused
    paused = not paused

# Define a function to display a paused message
def show_pause_message():
    pause_font = pygame.font.Font(None, 70)
    pause_text = pause_font.render("Paused", True, WHITE)
    screen.blit(pause_text, (SCREEN_WIDTH // 2 - pause_text.get_width() // 2, SCREEN_HEIGHT // 5))

    mouse_pause = pygame.mouse.get_pos()
    padding = 20

    pause_font2 = pygame.font.Font(None, 30)
    pause_text2 = pause_font2.render("  QUIT?  ", True, WHITE)
    
    pause_font3 = pygame.font.Font(None, 30)
    pause_text3 = pause_font3.render("  BACK?  ", True, WHITE)
    
    # Draw menu options
    screen.blit(pause_text2, (SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 50))
    screen.blit(pause_text3, (SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 10))

    # Highlight menu option if mouse is over it
    menu_text_rect = pause_text2.get_rect(topleft=(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 50))
    menu_text_rect2 = pause_text3.get_rect(topleft=(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 10))

    if menu_text_rect.inflate(padding, padding).collidepoint(mouse_pause):
        pygame.draw.rect(screen, WHITE, menu_text_rect.inflate(padding, padding), 2)
    elif menu_text_rect2.inflate(padding, padding).collidepoint(mouse_pause):
        pygame.draw.rect(screen, WHITE, menu_text_rect2.inflate(padding, padding), 2)

    pygame.display.update()

    # Event handling for menu buttons
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if menu_text_rect.collidepoint(mouse_pause):  # If "QUIT?" is clicked
                pygame.quit()
                sys.exit()
            elif menu_text_rect2.collidepoint(mouse_pause):  # If "BACK?" is clicked
                toggle_pause()  # Unpause the game

def spawn_enemies():
    # Spawn new enemies
    if random.randint(1, 150) <= player.level * 2:  # Increase spawn rate with player level
        if random.randint(1, 150) <= 2:  # 2% chance to spawn a boss
            boss_image = random.choice(["img/elite_enemy.png", "img/enemy2.png"])  # Add more boss images as needed
            boss = Boss(pygame.image.load(boss_image).convert_alpha(), random.randint(0, SCREEN_WIDTH), -50, 1, 50)  # Adjust boss parameters as needed
            enemies.add(boss)
            all_sprites.add(boss)
        elif random.randint(1, 150) <= 5:  # 5% chance to spawn a boss
            BigEnemy_image = random.choice(["img/big_enemy.png", "img/big_enemy2.png", "img/big_enemy3.png"])  # Add more Big Enemy images as needed
            bigbig = BigEnemy(pygame.image.load(BigEnemy_image).convert_alpha(), random.randint(0, SCREEN_WIDTH), -50, 1, 50)  # Adjust boss parameters as needed
            enemies.add(bigbig)
            all_sprites.add(bigbig)
        else:
            enemy_image = random.choice(["img/enemy.png", "img/enemy5.png", "img/enemy3.png", "img/enemy4.png", "img/asteroid.png"])
            enemy = Enemy(pygame.image.load(enemy_image).convert_alpha(), random.randint(0, SCREEN_WIDTH), -50, random.randint(1, 3) + player.level // 5, 10)  # Increase enemy speed with player level
            enemies.add(enemy)
            all_sprites.add(enemy)
            
def reset_enemies():
    # Remove all existing enemy sprites
    enemies.empty()
    
    # Spawn new enemies
    spawn_enemies()

def clear_remaining_enemies():
    # Remove any remaining enemy sprites from the game
    for enemy in enemies:
        enemy.kill()
        
def game_over_screen():
    while True:
        screen.blit(background, (0, 0))
        font = pygame.font.Font(None, 70)
        game_over_text = font.render("Game Over", True, WHITE)
        font2 = pygame.font.Font(None, 30)
        instruction_text = font2.render("Press any key to return to the main menu", True, WHITE)
        screen.blit(game_over_text, (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, SCREEN_HEIGHT // 2 - 30))
        screen.blit(instruction_text, (SCREEN_WIDTH // 2 - instruction_text.get_width() // 2, SCREEN_HEIGHT // 2 + 30))
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                return "main_menu"
            
            elif event.type == pygame.MOUSEBUTTONDOWN:
                return "main_menu"
        
def game_loop():
    clock = pygame.time.Clock()
    
    # Set player's initial position
    player.rect.centerx = SCREEN_WIDTH // 2
    player.rect.bottom = SCREEN_HEIGHT - 50

    while True:
        screen.blit(background, (0, 0))
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    toggle_pause()  # Toggle the pause state
                elif event.key == pygame.K_SPACE:
                    if not paused:
                        # Handle spacebar attack only if the game is not paused
                        bullet_img = bullet_imgs[player.bullet_level - 1]
                        bullet = Bullet(bullet_img, player.rect.centerx, player.rect.top, -5, 25)
                        bullets.add(bullet)
                        all_sprites.add(bullet)
                        shooting_sound.play()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left mouse button
                    if not paused:
                        # Handle left mouse button click for firing laser
                        bullet_img = bullet_imgs[player.bullet_level - 1]
                        bullet = Bullet(bullet_img, player.rect.centerx, player.rect.top, -5, 25)
                        bullets.add(bullet)
                        all_sprites.add(bullet)
                        shooting_sound.play()
                    
        
        # If the game is paused, display the paused message and skip the rest of the loop
        if paused:
            action = show_pause_message()
            if action == "main_menu":
                return "main_menu"
            continue

        # Spawn new enemies
        spawn_enemies()
        
        for enemy in enemies:
            if isinstance(enemy, Boss):
                enemy.shoot()

            if isinstance(enemy, BigEnemy):
                enemy.shoot()
        # Check for collisions between enemies and player bullets
        for enemy in enemies:
            hits = pygame.sprite.spritecollide(enemy, bullets, True)
            for hit in hits:
                enemy.health -= hit.damage
                if enemy.health <= 0:
                    enemy.kill()
                    explosion = Explosion(enemy.rect.centerx, enemy.rect.centery)
                    all_sprites.add(explosion)
                    # Remove the enemy sprite when its health reaches 0
                    if player.health < 100:
                        player.health += 0.5
                    
                                # Remove all bullets fired by this enemy
             
                    player.score += 10  # Increase score for each enemy destroyed
                    # Play destroyed sound
                    destroyed_sound.play()

                    if player.score > player.score_to_next_level:
                        player.level += 1
                        player.score_to_next_level += 200  # Increase score threshold for next level
                        # Additional level-up actions can be added here

                        # Bullet level up
                        if player.bullet_level < len(bullet_imgs):  # Ensure bullet level does not exceed available bullet images
                            player.bullet_level += 1

        for enemy in enemies:
            if pygame.sprite.collide_rect(player, enemy):
                # Trigger explosion animation for the collided enemy
                explosion = Explosion(enemy.rect.centerx, enemy.rect.centery)
                all_sprites.add(explosion)
                # Play collision sound
                collision_sound.play()
                # Decrease player's health and increase score
                player.health -= 10
                player.score += 10
                # Remove the collided enemy
                enemy.kill()
                
        # Check for collisions between player and boss's bullets
        hits = pygame.sprite.spritecollide(player, lasers, True)
        for hit in hits:
            player.health -= 10  # Decrease player health when hit by boss's bullet
            hit_sound.play()
        
        # Draw
        all_sprites.update()

        # Draw
        for sprite in all_sprites:
            screen.blit(sprite.image, sprite.rect)
            if isinstance(sprite, Enemy) or isinstance(sprite, Boss):
                sprite.draw_health_bar()

        # Draw player health
        pygame.draw.rect(screen, GREEN, (10, 10, player.health * 2, 20))

        # Draw score and level
        font = pygame.font.Font(None, 36)
        score_text = font.render("Score: " + str(player.score), True, WHITE)
        level_text = font.render("Level: " + str(player.level), True, WHITE)
        screen.blit(score_text, (10, 40))
        screen.blit(level_text, (10, 70))

        pygame.display.flip()
        clock.tick(60)
        pygame.display.update()

        # Check if the player is dead and return to the main menu if so
        if player.health <= 0:
            # Reset player health and score
            player.health = 100
            player.score = 0
            player.level = 1
            player.score_to_next_level = 200
            player.bullet_level = 1
            
            # Reset enemies' positions and spawn new enemies
            clear_remaining_enemies()
            reset_enemies()
            
            lost_sound.play()
            result = game_over_screen()
            if result == "main_menu":
                return "main_menu"

# Define the main menu function
def main_menu():
    
    global selected_spaceship_index
    while True:
        screen.blit(background, (0, 0))
        pygame.mixer.music.stop()
        font_title = pygame.font.Font(None, 60)
        font_title2 = pygame.font.Font(None, 40)
        title_text = font_title.render("Space Shooter:", True, WHITE)
        title_text2 = font_title2.render("The Defender of Cosmos", True, WHITE)
        screen.blit(title_text, (SCREEN_WIDTH // 2 - title_text.get_width() // 2, SCREEN_HEIGHT // 7))
        screen.blit(title_text2, (SCREEN_WIDTH // 2 - title_text2.get_width() // 2, SCREEN_HEIGHT // 4.5))
        # Create text objects for menu options
        font = pygame.font.Font(None, 50)
        font2 = pygame.font.Font(None, 25)
        play_text = font.render("Play Game", True, WHITE)
        quit_text = font.render("Quit", True, WHITE)
        choose_ship_text = font2.render("Change Spaceship", True, WHITE)  # New button text

        # Get mouse position
        mouse_pos = pygame.mouse.get_pos()

        # Define padding
        padding = 15

        # Draw menu options
        screen.blit(play_text, (SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 10))
        screen.blit(quit_text, (SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 50))
        screen.blit(choose_ship_text, (SCREEN_WIDTH // 8 - choose_ship_text.get_width() // 2, SCREEN_HEIGHT // 2 + 260))  # Draw new button

        # Highlight menu option if mouse is over it
        play_text_rect = play_text.get_rect(topleft=(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 10))
        quit_text_rect = quit_text.get_rect(topleft=(SCREEN_WIDTH // 2 - 50, SCREEN_HEIGHT // 2 + 50))
        choose_ship_rect = choose_ship_text.get_rect(topleft=(SCREEN_WIDTH // 8 - choose_ship_text.get_width() // 2, SCREEN_HEIGHT // 2 + 260))  # Define new button rect
        

        
        if play_text_rect.inflate(padding, padding).collidepoint(mouse_pos):
            pygame.draw.rect(screen, WHITE, play_text_rect.inflate(padding, padding), 2)
        elif quit_text_rect.inflate(padding, padding).collidepoint(mouse_pos):
            pygame.draw.rect(screen, WHITE, quit_text_rect.inflate(padding, padding), 2)
        elif choose_ship_rect.inflate(padding, padding).collidepoint(mouse_pos):  # Highlight new button
            pygame.draw.rect(screen, WHITE, choose_ship_rect.inflate(padding, padding), 2)


        draw_spaceship()
        # Event handling for menu buttons
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if play_text_rect.collidepoint(mouse_pos):
                    return "play"
                elif quit_text_rect.collidepoint(mouse_pos):
                    return "quit"
                elif choose_ship_rect.collidepoint(mouse_pos):
                    # Change spaceship when "Change Spaceship" button is clicked
                    change_spaceship()
                    

        pygame.display.update()

# Call the main menu function
while True:
    action = main_menu()
    if action == "play":
        pygame.mixer.music.rewind()
        pygame.mixer.music.play()
        player.image = player_img[selected_spaceship_index] 
        result = game_loop()
    elif action == "quit":
        pygame.quit()
        sys.exit()
    elif action == "choose_ship":
        pass
